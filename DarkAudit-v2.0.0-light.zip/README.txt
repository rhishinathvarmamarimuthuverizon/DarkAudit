DarkAudit v2.0.0 - Android Security Assessment Platform

Usage:
  Double-click DarkAudit.bat (requires Java 11+ installed)
  OR: java -jar DarkAudit.jar

CLI: java -jar DarkAudit.jar --scan app.apk --format sarif
API: java -jar DarkAudit.jar --server --port 8089
